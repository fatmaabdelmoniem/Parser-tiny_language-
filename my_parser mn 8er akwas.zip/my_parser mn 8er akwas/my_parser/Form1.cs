﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace my_parser
{

    public partial class Form1 : Form
    {
        public class token
        {
            public string token_value;
            public string token_type;
        }

        int pos = 0;
        int level = 0;
        int length;
        int terminal_flag = 0;
        token fatma;

        int operator_flag = 0;

        /* struct token
         {
             string token_value;
             string token_type;
         };*/
        public static List<token> tokens = new List<token>();
        static token currentToken;
        TreeNode currentNode;
        Stack<TreeNode> lastNode = new Stack<TreeNode>(100);
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        private string erase_space(string x)
        {
            string y = "";
            for (int i = 0; i < x.Length; i++)
            {
                if (x[i] == ' ')
                {
                    continue;
                }
                y += x[i];
            }
            return y;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        void Parse()
        {

            currentNode = treeView1.Nodes.Add("Node" + level, "Start");
            stmt_sequence();
        }

        void stmt_sequence()
        {

            statement();
            if (((((tokens[pos]).token_type) != "SEMICOLON") && ((((tokens[pos]).token_type) != "ELSE") && (((tokens[pos]).token_type) != "UNTIL") && (((tokens[pos]).token_type) != "END"))) && terminal_flag == 0)
            {
                MessageBox.Show("WARN !!" + "\n" + "YOU MISSED ; BEFORE: " + (tokens[pos]).token_value + "\n" + "SOME STATEMENTS WILL BE MISSED");

            }

            while ((((tokens[pos]).token_type) == "SEMICOLON") && terminal_flag == 0)
            {
                match("SEMICOLON");
                statement();
            }
            if (((((tokens[pos]).token_type) == "UNTIL") || (((tokens[pos]).token_type) == "ELSE")) && terminal_flag == 1)
            {
                MessageBox.Show("UNEXPECTED INPUT !!" + "\n" + "ERROR at: " + (tokens[pos]).token_value);
                Application.Restart();
            }


        }

        void statement()
        {
            if (((tokens[pos]).token_type) == "IF") { if_stmt(); }
            else if (((tokens[pos]).token_type) == "IDENTIFIER") { assign_stmt(); }
            else if (((tokens[pos]).token_type) == "READ") { read_stmt(); }
            else if (((tokens[pos]).token_type) == "WRITE") { write_stmt(); }
            else if (((tokens[pos]).token_type) == "REPEAT") { repeat_stmt(); }
            /*else
            {
                cout << "BIG ERROR";
                exit(1);
            }*/

        }

        ///////////////////////////////////////////////////////////////////////

        void if_stmt()
        {
            lastNode.Push(currentNode);
            currentNode = currentNode.Nodes.Add("if");
            match("IF");
            level++;
            exp();

            match("THEN");
            level--;
            stmt_sequence();
            if (((tokens[pos]).token_type == "ELSE"))
            {
                match("ELSE");
                stmt_sequence();
            }
            match("END");
            level--;
            currentNode = lastNode.Pop();
        }


        void repeat_stmt()
        {
            lastNode.Push(currentNode);
            currentNode = currentNode.Nodes.Add("repeat");
            match("REPEAT");
            level++;
            stmt_sequence();
            currentNode = lastNode.Pop();
            match("UNTIL");
            exp();
            level -= 2;
            currentNode = lastNode.Pop();
        }

        void assign_stmt()
        {
            lastNode.Push(currentNode);
            currentNode = currentNode.Nodes.Add("assign " + tokens[pos].token_value);
            match("IDENTIFIER");
            match("ASSIGN");
            if ((pos + 1 < length) && (tokens[pos + 1].token_type == "PLUS" || tokens[pos + 1].token_type == "MINUS"
                || tokens[pos + 1].token_type == "MULT" || tokens[pos + 1].token_type == "DIV"))
            {

                level++;
                exp();
                level -= 2;
            }
            else
            {
                exp();
                level--;
            }
            currentNode = lastNode.Pop();
        }

        void read_stmt()
        {
            lastNode.Push(currentNode);
            match("READ");
            currentNode = currentNode.Nodes.Add("read " + tokens[pos].token_value);
            match("IDENTIFIER");
            currentNode = lastNode.Pop();

        }

        void write_stmt()
        {
            lastNode.Push(currentNode);
            currentNode = currentNode.Nodes.Add("write");
            match("WRITE");
            exp();
            level--;
            currentNode = lastNode.Pop();

        }


        //////////////////////////////////////////////////////////////////////////////////////////

        void exp()
        {
            level++;
            simple_exp();
            if (((tokens[pos]).token_type == "LESSTHAN") || ((tokens[pos]).token_type == "EQUAL"))
            {


                if (operator_flag == 1)
                {
                    currentNode = currentNode.Nodes.Add("op " + tokens[pos].token_value);
                    lastNode.Push(currentNode);
                    if (fatma.token_type == "NUMBER") { currentNode = currentNode.Nodes.Add("CONST " + fatma.token_value); }
                    else if (fatma.token_type == "IDENTIFIER") { currentNode = currentNode.Nodes.Add("ID " + fatma.token_value); }
                    else { currentNode = currentNode.Nodes.Add(fatma.token_value); }
                    currentNode = lastNode.Pop();
                    operator_flag = 0;


                }
                else
                {
                    lastNode.Push(currentNode);
                    currentNode = currentNode.Nodes.Add("op " + tokens[pos].token_value);
                }
                level--;
                comparison_op();
                level++;
                simple_exp();
                currentNode = lastNode.Pop();

            }

        }

        void comparison_op()
        {
            if (((tokens[pos]).token_type == "LESSTHAN"))
            {
                match("LESSTHAN");
            }
            else if (((tokens[pos]).token_type == "EQUAL"))
            {
                match("EQUAL");
            }

        }

        void simple_exp()
        {

            term();

            while (((tokens[pos]).token_type == "PLUS") || ((tokens[pos]).token_type == "MINUS"))
            {

                if (operator_flag == 1)
                {
                    currentNode = currentNode.Nodes.Add("op " + tokens[pos].token_value);
                    lastNode.Push(currentNode);
                    if (fatma.token_type == "NUMBER") { currentNode = currentNode.Nodes.Add("CONST " + fatma.token_value); }
                    else if (fatma.token_type == "IDENTIFIER") { currentNode = currentNode.Nodes.Add("ID " + fatma.token_value); }
                    else { currentNode = currentNode.Nodes.Add(fatma.token_value); }
                    currentNode = lastNode.Pop();
                    operator_flag = 0;


                }
                else
                {
                    lastNode.Push(currentNode);
                    currentNode = currentNode.Nodes.Add("op " + tokens[pos].token_value);
                }
                level--;
                add_op();
                level++;

                term();
                currentNode = lastNode.Pop();
            }
        }

        void add_op()
        {
            if (((tokens[pos]).token_type == "PLUS"))
            {
                match("PLUS");
            }
            else if (((tokens[pos]).token_type == "MINUS"))
            {
                match("MINUS");

            }

        }

        void term()
        {
            factor();

            while (((tokens[pos]).token_type == "MULT") || ((tokens[pos]).token_type == "DIV"))
            {

                if (operator_flag == 1)
                {
                    currentNode = currentNode.Nodes.Add("op " + tokens[pos].token_value);
                    lastNode.Push(currentNode);
                    if (fatma.token_type == "NUMBER") { currentNode = currentNode.Nodes.Add("CONST " + fatma.token_value); }
                    else if (fatma.token_type == "IDENTIFIER") { currentNode = currentNode.Nodes.Add("ID " + fatma.token_value); }
                    else { currentNode = currentNode.Nodes.Add(fatma.token_value); }
                    currentNode = lastNode.Pop();
                    operator_flag = 0;


                }
                else
                {
                    lastNode.Push(currentNode);
                    currentNode = currentNode.Nodes.Add("op " + tokens[pos].token_value);
                }
                level--;
                mul_op();
                level++;
                // currentNode = lastNode.Pop();
                factor();

            }
        }

        void mul_op()
        {
            if (((tokens[pos]).token_type == "MULT"))
            {
                match("MULT");
            }
            else if (((tokens[pos]).token_type == "DIV"))
            {
                match("DIV");
            }

        }

        void factor()
        {
            if (((tokens[pos]).token_type == "NUMBER"))
            {

                lastNode.Push(currentNode);
                if ((pos + 1 < length) && (((tokens[pos + 1]).token_type == "LESSTHAN") || ((tokens[pos + 1]).token_type == "EQUAL") || ((tokens[pos + 1]).token_type == "PLUS") || ((tokens[pos + 1]).token_type == "MINUS") || ((tokens[pos + 1]).token_type == "MULT") || ((tokens[pos + 1]).token_type == "DIV")))
                {
                    fatma = tokens[pos];
                    operator_flag = 1;
                }
                else
                {
                    currentNode = currentNode.Nodes.Add("CONST " + tokens[pos].token_value);
                    currentNode = lastNode.Pop();
                }
                match("NUMBER");


            }
            else if (((tokens[pos]).token_type == "IDENTIFIER"))
            {
                lastNode.Push(currentNode);
                if ((pos + 1 < length) && (((tokens[pos + 1]).token_type == "LESSTHAN") || ((tokens[pos + 1]).token_type == "EQUAL") || ((tokens[pos + 1]).token_type == "PLUS") || ((tokens[pos + 1]).token_type == "MINUS") || ((tokens[pos + 1]).token_type == "MULT") || ((tokens[pos + 1]).token_type == "DIV")))
                {
                    fatma = tokens[pos];
                    operator_flag = 1;
                }
                else
                {
                    currentNode = currentNode.Nodes.Add("ID " + tokens[pos].token_value);
                    currentNode = lastNode.Pop();
                }
                match("IDENTIFIER");


            }

            else if (((tokens[pos]).token_type == "OPENBRACKET"))
            {
                // lastNode.Push(currentNode);
                // currentNode.Nodes.Add("(");
                match("OPENBRACKET");
                exp();
                level--;
                currentNode = lastNode.Pop();
                // currentNode.Nodes.Add(")");
                match("CLOSEDBRACKET");
                // currentNode = lastNode.Pop();

            }
            else
            {
                MessageBox.Show("UNEXPECTED INPUT !!" + "\n" + "ERROR at: " + (tokens[pos]).token_value);
                Application.Restart();
            }
        }

        void match(string x)
        {
            if (((tokens[pos]).token_type == x))
            {
                if (pos < length)
                {
                    currentToken = tokens[pos];
                    
                    pos++;
                    if (pos == length)
                    {
                        terminal_flag = 1;
                           pos--;
                    }

                }
                return;
            }
            else
            {
                MessageBox.Show("ERROR : UNACCEPTED TINY LANGUAGE");
                Application.Restart();
            }

        }

        /// </summary>


        OpenFileDialog fbd = new OpenFileDialog();

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        { }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            treeView1.ExpandAll();
           // treeView1.CollapseAll();
        }

        string path;


        private void button1_Click(object sender, EventArgs e)
        {
            fbd.Filter = "GBD|*.txt";
            if (fbd.ShowDialog() != DialogResult.OK)
                MessageBox.Show("Error opening file");
             path = fbd.FileName;
            textBox1.Text = path;
            //System.IO.StreamReader file = new System.IO.StreamReader(@path);
        }

        private void button2_Click(object sender, EventArgs e)
        {
          currentToken = null ;
          currentNode = null;
          tokens.Clear();
          lastNode.Clear();
          treeView1.Nodes.Clear();
          checkBox1.Checked = false;
          pos = 0;

            List<string> s = new List<string>();
            int n;
            string str1;
            string str2;
            System.IO.StreamReader file = new System.IO.StreamReader(path);

            while (((str1 = file.ReadLine()) != null))
            {
                if ((str1 != ""))
                {
                    str2 = erase_space(str1);
                    n = str2.IndexOf(',');
                    string x = str2.Substring(0, n);
                    string yx = str2.Substring(n + 1, str2.Length - n - 1);
                    tokens.Add(new token { token_value = x, token_type = yx });
                }
            }

            length = tokens.Count;
            Parse();

        }

        private void treeView1_AfterSelect_1(object sender, TreeViewEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}


